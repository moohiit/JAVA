gengp = new ButtonGroup();
        gengp.add(male);
        gengp.add(female);
