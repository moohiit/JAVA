//1.WAP  to print Introduction of Java. 
// (which includes Developer of java,
// Original name of java , year of 
// Java , basic feature of Java.)

public class _1_Introduction_to_Java {
    public static void main(String[] args) {
        System.out.println("\t** Introduction to JAVA **");
        System.out.println("Java was developed by James Gosling.");
        System.out.println("Original name java was : OAK.");
        System.out.println("Deleopment year of java is 1995.");
        System.out.println("It is pure Object oriented Language.");
        System.out.println("You can't create any program without using the class.");
    }
}
